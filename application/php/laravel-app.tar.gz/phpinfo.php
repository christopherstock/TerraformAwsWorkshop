<?php

    phpinfo();
